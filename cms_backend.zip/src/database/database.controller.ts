import { Controller } from '@nestjs/common';

@Controller('database')
export class DatabaseController {}
